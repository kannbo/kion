import kion
import PySimpleGUI as sg
import pyautogui,requests
import kosa
#print(str(kosa.filename).split("]"))
pyautogui.confirm(text="このアプリは気象庁のAPIを使っています", title="起動するアプリの選択",
                        buttons=["了解"])
area=130000
forecast_url = f"https://www.jma.go.jp/bosai/forecast/data/overview_forecast/{area}.json"
forecast_req = requests.get(forecast_url)
forecast_data = forecast_req.json() # 天気概況
forecast_text = "\n".join(forecast_data["text"].split())
#print(forecast_text)
kikou=[[sg.Image(kosa.filename,size=(600,500))]]
window=sg.Window("気温確認",kikou, resizable=True,font=(["keifont","UD デジタル 教科書体 N-B"][1],10),size=(700, 700))
from win11toast import toast

#toast('roadが完了しました')

while True:
    event,hoge=window.read()
    if event==sg.WIN_CLOSED:
            window.close()
            break
