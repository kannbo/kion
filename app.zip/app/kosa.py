import urllib.request as req
import datetime
from PIL import Image

now_raw = datetime.datetime.now()

now = now_raw.strftime('%Y%m%d')

now2 = now_raw.strftime('%Y%m%d%H')
print(now)
url = "https://www.data.jma.go.jp/gmd/env/kosa/obs/img/jp/"+now+"_kosaobs_jp_jp.png"
filename="image/kosa"+now2+".png"

print(url)
with req.urlopen(url) as web_file:
    with open(filename, 'wb') as local_file:
        local_file.write(web_file.read())
img = Image.open(filename)
img_resize = img.resize((int(img.width / 2), int(img.height / 2)))
img_resize.save(filename)
